import './App.css';
import Contador from './components/Contador';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      numero: 0,
    };
  }

  incrementar = () => {
    this.setState((prevState) => ({ numero: prevState.numero + 1 }));
  };

  decrementar = () => {
    this.setState((prevState) => ({ numero: prevState.numero - 1 }));
  };

  resetear = () => {
    this.setState({ numero: 0 });
  };

  render() {
    return (
      <>
        <Contador
          incrementar={this.incrementar}
          decrementar={this.decrementar}
          resetear={this.resetear}
          numero={this.state.numero}
        />
      </>
    );
  }
}

export default App;
