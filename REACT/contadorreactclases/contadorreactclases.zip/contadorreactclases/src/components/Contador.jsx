import './Contador.css';

class Contador extends Component {
    render() {
        const { numero, incrementar, decrementar, resetear } = this.props;

        return (
            <div className="container-counter">
                <div className="counter">
                    <h1>{numero}</h1>
                </div>
                <div className="buttons">
                    <button onClick={incrementar} className="incButton">
                        Incrementar
                    </button>

                    <button onClick={decrementar}>
                        Decrementar
                    </button>

                    <button onClick={resetear}>
                        Resetear
                    </button>
                </div>
            </div>
        );
    }
}

export default Contador;
