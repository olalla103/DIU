package com.example.AgendaR;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgendaRApplicationTests {

	@Test
	void contextLoads() {
	}

}
