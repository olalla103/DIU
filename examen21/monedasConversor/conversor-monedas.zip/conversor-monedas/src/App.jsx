import './App.css'
import Conversor1 from './components/Conversor1'
import Conversor2 from './components/Conversor2'

function App() {

  return (
    <>
      <Conversor1 />
      {/* <Conversor2 /> */}
    </>
  )
}

export default App