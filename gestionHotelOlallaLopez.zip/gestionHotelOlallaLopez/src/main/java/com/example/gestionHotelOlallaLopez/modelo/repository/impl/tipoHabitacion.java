package com.example.gestionHotelOlallaLopez.modelo.repository.impl;

public enum tipoHabitacion {
    DOBLEDEUSOINDIVIDUAL, DOBLE, JUNIOR, SUITE
}
