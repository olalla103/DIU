package org.example.gestionhotel.model.repository.impl;

public enum tipoHabitacion {
    DOBLEDEUSOINDIVIDUAL, DOBLE, JUNIOR, SUITE
}
