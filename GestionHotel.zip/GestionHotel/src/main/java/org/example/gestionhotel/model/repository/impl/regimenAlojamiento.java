package org.example.gestionhotel.model.repository.impl;

public enum regimenAlojamiento {
    ALOJAMIENTOYDESAYUNO, MEDIAPENSION, PENSIONCOMPLETA, SOLOALOJAMIENTO
}
