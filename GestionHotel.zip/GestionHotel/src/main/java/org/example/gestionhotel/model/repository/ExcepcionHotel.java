package org.example.gestionhotel.model.repository;

public class ExcepcionHotel extends RuntimeException {
    public ExcepcionHotel(String message) {
        super(message);
    }
}
