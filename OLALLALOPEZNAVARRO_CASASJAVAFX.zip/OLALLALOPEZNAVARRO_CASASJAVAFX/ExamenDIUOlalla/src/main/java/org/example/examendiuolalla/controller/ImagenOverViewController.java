package org.example.examendiuolalla.controller;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import org.example.examendiuolalla.view.Moneda;

public class ImagenOverViewController {
    // no me da tiempo

    @FXML
    Label catnMonedas;

    public void handleCantidadMonedas() {

    }

    public void setMonedaData(ObservableList<Moneda> monedaData) {

    }
}
