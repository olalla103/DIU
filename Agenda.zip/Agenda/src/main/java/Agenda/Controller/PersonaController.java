package Agenda.Controller;

import Agenda.Main;
import Agenda.Modelo.PersonaException;
import Agenda.Modelo.PersonaModelo;
import Agenda.Modelo.PersonaVO;
import Agenda.Persona;
import javafx.beans.Observable;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.util.ArrayList;

public class PersonaController {
    private PersonaModelo personaModelo;
    private ArrayList<Persona> personas;

    //private boolean onClicked;

    @FXML
    private TableView<Persona> TablaDetalles;
    @FXML
    private TableColumn<Persona, String> ColumnaNombre;
    @FXML
    private TableColumn<Persona, String> ColumnApellido;
    @FXML
    private TextField cajaNombre;
    @FXML
    private TextField cajaSexo;
    @FXML
    private TextField cajaApellidos;
    @FXML
    private TextField cajaCorreo;
    @FXML
    private TextField cajaCodigoPostal;
    @FXML
    private TextField cajaEdad;
    @FXML
    private TextField campoIntroducEdad;
    @FXML
    private Button addBtn;
    @FXML
    private Button editBtn;
    @FXML
    private Button deleteBtn;


    Main main;

    private void showPersonDetails(Persona persona) {
        if (persona != null) {
            cajaNombre.setText(persona.getNombre());
            cajaApellidos.setText(persona.getApellidos());
            cajaCorreo.setText(persona.getCorreo());
            cajaEdad.setText(String.valueOf(persona.getEdad()));
            cajaSexo.setText(persona.getSexo());
            cajaCodigoPostal.setText(persona.getCodigoPostal());
        } else {
            cajaNombre.setText("");
            cajaApellidos.setText("");
            cajaCorreo.setText("");
            cajaEdad.setText("");
            cajaSexo.setText("");
            cajaCodigoPostal.setText("");
        }
    }

    @FXML
    private void initialize() {
        ColumnaNombre.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getNombre()));
        ColumnApellido.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getApellidos()));

        showPersonDetails(null);

        TablaDetalles.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> showPersonDetails(newValue));
    }


    public void setModelo(PersonaModelo personaModelo) {
        this.personaModelo = personaModelo;
    }

    public void setMain(Main main) {
        this.main = main;
    }

    public void setPersona() throws PersonaException {
        personas = personaModelo.setPersona();
        TablaDetalles.setItems(FXCollections.observableArrayList(personas));

        for (Persona p : personas) {
            System.out.println("Nombre: " + p.getNombre() + ", Apellido: " + p.getApellidos());
        }
    }

    public void aniadirPersona(Persona persona){
        personas.add(persona);
        TablaDetalles.getItems().add(persona);
    }

    @FXML
    public void handleAdd() throws IOException {
        main.abrirAdd();
    }


    @FXML
    public void handleEdit() throws IOException {
        Persona personaTemp = TablaDetalles.getSelectionModel().getSelectedItem();
        if (personaTemp != null){
            main.abrirAdd(personaTemp);
        }

    }

    public void editPersona(Persona persona){
        for (int i=0;i<personas.size();i++){
            if (personas.get(i).getId()==persona.getId()){
                personas.remove(i);
                personas.add(persona);
                TablaDetalles.setItems(FXCollections.observableArrayList(personas));
                return;
            }
        }
    }

    @FXML
    public void handleDelete() {
        personaModelo.eliminarPersona(buscarId());

    }
    public Integer buscarId(){
        int selectedIndex = TablaDetalles.getSelectionModel().getSelectedIndex();
        if (selectedIndex >= 0) {
            personas.remove(TablaDetalles.getItems().get(selectedIndex));
            TablaDetalles.getItems().remove(selectedIndex);
            return selectedIndex;
        }
        return 0;
    }

    public void setData(ObservableList<Persona> lista) {
        TablaDetalles.setItems(lista);
    }


}
