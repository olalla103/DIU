package Agenda.Controller;

import Agenda.Modelo.PersonaModelo;
import Agenda.Persona;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


public class AddController {
    private PersonaModelo personaModelo;
    private Stage addStage;
    PersonaController personaController;

    @FXML
    private TextField nombre;
    @FXML
    private TextField edad;
    @FXML
    private TextField apellido;
    @FXML
    private TextField correo;
    @FXML
    private TextField codigoPostal;
    @FXML
    private TextField sexo;
    private boolean edit;
    private Integer id;

    public void handleAdd() {
        if (edit) {
            personaModelo.editarPersona(crearPersona());
            personaController.editPersona(crearPersona());
        } else {
            personaModelo.aniadirPersona(crearPersona());
            personaController.aniadirPersona(crearPersona());
        }

        addStage.close();
    }

    public void setCampos(Persona persona) {
        this.id = persona.getId();
        nombre.setText(persona.getNombre());
        apellido.setText(persona.getApellidos());
        correo.setText(persona.getCorreo());
        edad.setText(String.valueOf(persona.getEdad()));
        codigoPostal.setText(persona.getCodigoPostal());
        sexo.setText(persona.getSexo());
    }

    public void setEdit(boolean edit) {
        this.edit = edit;
    }

    public void setAddStage(Stage addStage) {
        this.addStage = addStage;
    }

    public void setPersonaModelo(PersonaModelo personaModelo) {
        this.personaModelo = personaModelo;
    }

    public void setPersonaController(PersonaController personaController) {
        this.personaController = personaController;
    }

    public Persona crearPersona() {
        if (edit) {
            return new Persona(id, nombre.getText(), apellido.getText(), Integer.valueOf(edad.getText()),
                    codigoPostal.getText(), correo.getText(), sexo.getText());
        } else {
            return new Persona(personaModelo.getLastId(), nombre.getText(), apellido.getText(), Integer.valueOf(edad.getText()),
                    codigoPostal.getText(), correo.getText(), sexo.getText());
        }
    }
}
