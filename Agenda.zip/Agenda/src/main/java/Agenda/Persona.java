package Agenda;

import javafx.beans.property.*;

public class Persona {
    private IntegerProperty id;
    private StringProperty nombre;
    private StringProperty apellidos;
    private IntegerProperty edad;
    private StringProperty codigoPostal;
    private StringProperty correo;
    private StringProperty sexo;

    // Constructor que recibe valores primitivos y los convierte en propiedades
    public Persona(int id, String nombre, String apellidos, int edad, String codigoPostal, String correo, String sexo) {
        this.id = new SimpleIntegerProperty(id);
        this.nombre = new SimpleStringProperty(nombre);
        this.apellidos = new SimpleStringProperty(apellidos);
        this.edad = new SimpleIntegerProperty(edad);
        this.codigoPostal = new SimpleStringProperty(codigoPostal);
        this.correo = new SimpleStringProperty(correo);
        this.sexo = new SimpleStringProperty(sexo);
    }

    public int getId() {
        return id.get();
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public String getNombre() {
        return nombre.get();
    }

    public void setNombre(String nombre) {
        this.nombre.set(nombre);
    }

    public String getApellidos() {
        return apellidos.get();
    }

    public void setApellidos(String apellidos) {
        this.apellidos.set(apellidos);
    }

    public int getEdad() {
        return edad.get();
    }

    public void setEdad(int edad) {
        this.edad.set(edad);
    }

    public String getCodigoPostal() {
        return codigoPostal.get();
    }

    public void setCodigoPostal(String codigoPostal) {
        this.codigoPostal.set(codigoPostal);
    }

    public String getCorreo() {
        return correo.get();
    }

    public void setCorreo(String correo) {
        this.correo.set(correo);
    }

    public String getSexo() {
        return sexo.get();
    }

    public void setSexo(String sexo) {
        this.sexo.set(sexo);
    }

    @Override
    public String toString() {
        return "Persona{" +
                "id=" + id.get() +
                ", nombre='" + nombre.get() + '\'' +
                ", apellidos='" + apellidos.get() + '\'' +
                ", edad=" + edad.get() +
                ", codigoPostal='" + codigoPostal.get() + '\'' +
                ", correo='" + correo.get() + '\'' +
                ", sexo='" + sexo.get() + '\'' +
                '}';
    }
}
