package Agenda.Modelo;

import Agenda.Modelo.Repository.PersonaRepository;
import Agenda.Persona;
import Agenda.Util.PersonaUtil;

import java.util.ArrayList;

public class PersonaModelo {
    PersonaRepository personaRepository;

    public PersonaModelo() {

    }

    public void setPersonaRepository(PersonaRepository impl) throws PersonaException {
        this.personaRepository = impl;
    }

    public ArrayList<Persona> setPersona() {
        ArrayList<PersonaVO> personaVOS = this.personaRepository.ObtenerListaPersonas();
        System.out.println(personaVOS);
        return PersonaUtil.convertirVo(personaVOS);
    }

    public void aniadirPersona(Persona persona) {
        personaRepository.addPersona(PersonaUtil.convertirVo(persona));
    }
    public int getLastId(){
        return personaRepository.getLastId();
    }
    public void eliminarPersona(Integer var1){
        personaRepository.deletePersona(var1);
    }
    public void editarPersona(Persona persona){
        personaRepository.editPersona(PersonaUtil.convertirVo(persona));
    }
}
