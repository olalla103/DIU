package Agenda.Modelo.Repository;

import Agenda.Modelo.PersonaException;
import Agenda.Modelo.PersonaVO;

import java.util.ArrayList;

public interface PersonaRepository {
    ArrayList<PersonaVO> ObtenerListaPersonas() throws PersonaException;

    void addPersona(PersonaVO var1) throws PersonaException;

    void deletePersona(Integer var1) throws PersonaException;

    void editPersona(PersonaVO var1) throws PersonaException;

    int getLastId() throws PersonaException;

}
