package Agenda.Modelo.Repository.Impl;

import Agenda.Modelo.PersonaException;
import Agenda.Modelo.PersonaVO;
import Agenda.Modelo.Repository.PersonaRepository;

import java.util.ArrayList;

public class PersonaRepositoryImpl implements PersonaRepository {
    ArrayList<PersonaVO> personaVOS = new ArrayList<>();

    @Override
    public ArrayList<PersonaVO> ObtenerListaPersonas() throws PersonaException {
        System.out.println(personaVOS);
        return personaVOS;
    }

    @Override
    public void addPersona(PersonaVO var1) throws PersonaException {
        personaVOS.add(var1);
    }

    @Override
    public void deletePersona(Integer var1) throws PersonaException {
        BorrarPorId(var1);
    }

    public void BorrarPorId(Integer var1){
        for (int i=0;i<personaVOS.size();i++){
            if (personaVOS.get(i).getId() == var1){
                personaVOS.remove(i);
                return;
            }
        }
    }

    @Override
    public void editPersona(PersonaVO var1) throws PersonaException {
        personaVOS.remove(var1.getId());
        personaVOS.add(var1);
    }

    @Override
    public int getLastId() throws PersonaException {
        int cont = 0;
        for (int i = 0; i < personaVOS.size(); i++) {
            cont++;
        }
        return cont + 1;
    }


    public void datosIniciales() {
        personaVOS.add(new PersonaVO(1, "Juan", "Pérez", 30, "28001", "juan.perez@email.com", "Masculino"));
        personaVOS.add(new PersonaVO(2, "Ana", "García", 25, "28002", "ana.garcia@email.com", "Femenino"));
        personaVOS.add(new PersonaVO(3, "Carlos", "Fernández", 40, "28003", "carlos.fernandez@email.com", "Masculino"));
        personaVOS.add(new PersonaVO(4, "Laura", "Martínez", 35, "28004", "laura.martinez@email.com", "Femenino"));
        personaVOS.add(new PersonaVO(5, "David", "López", 28, "28005", "david.lopez@email.com", "Masculino"));

    }
}
