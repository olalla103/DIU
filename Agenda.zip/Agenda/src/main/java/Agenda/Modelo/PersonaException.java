package Agenda.Modelo;

public class PersonaException extends RuntimeException {
    private String mensaje;

    public PersonaException() {
    }

    public PersonaException(String message) {
        this.mensaje = message;
    }

    public String imprimirMensaje() {
        return this.mensaje;
    }
}
