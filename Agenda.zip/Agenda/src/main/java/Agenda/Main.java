package Agenda;

import Agenda.Controller.AddController;
import Agenda.Controller.PersonaController;
import Agenda.Modelo.PersonaException;
import Agenda.Modelo.PersonaModelo;
import Agenda.Modelo.Repository.Impl.PersonaRepositoryImpl;
import Agenda.Modelo.Repository.PersonaRepository;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

public class Main extends Application {
    private Stage primaryStage;
    private PersonaController controller;
    private PersonaModelo personaModelo = new PersonaModelo();
    private PersonaRepositoryImpl personaRepositoryImpl = new PersonaRepositoryImpl();
    private AddController addController;

    @Override
    public void start(Stage primaryStage) throws PersonaException, IOException {
        this.primaryStage = primaryStage;
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/agenda/VistaPersona.fxml"));
        Parent root = loader.load();
        controller = loader.getController();
        controller.setMain(this);
        personaRepositoryImpl.datosIniciales();
        personaModelo.setPersonaRepository(personaRepositoryImpl);
        controller.setModelo(personaModelo);
        controller.setPersona();

        Scene scene = new Scene(root, 800, 600);
        this.primaryStage.setScene(scene);
        this.primaryStage.setTitle("Agenda");
        this.primaryStage.show();
    }

    public void abrirAdd() throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("/com/example/agenda/AddView.fxml"));
        Parent root = loader.load();
        addController = loader.getController();


        Stage addStage = new Stage();
        addStage.setTitle("Añadir");
        addStage.initOwner(primaryStage);
        addController.setAddStage(addStage);
        addController.setPersonaModelo(personaModelo);
        addController.setPersonaController(controller);
        addController.setEdit(false);

        Scene scene = new Scene(root, 600, 600);
        addStage.setScene(scene);
        addStage.showAndWait();


    }

    public void abrirAdd(Persona persona) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("/com/example/agenda/AddView.fxml"));
        Parent root = loader.load();
        addController = loader.getController();


        Stage addStage = new Stage();
        addStage.setTitle("Añadir");
        addStage.initOwner(primaryStage);
        addController.setAddStage(addStage);
        addController.setPersonaModelo(personaModelo);
        addController.setPersonaController(controller);
        addController.setCampos(persona);
        addController.setEdit(true);

        Scene scene = new Scene(root, 600, 600);
        addStage.setScene(scene);
        addStage.showAndWait();


    }
}
