package Agenda.Util;

import Agenda.Modelo.PersonaVO;
import Agenda.Persona;

import java.util.ArrayList;

public class PersonaUtil {
    static ArrayList<Persona> personas = new ArrayList<>();

    public PersonaUtil() {
    }

    public static ArrayList<Persona> convertirVo(ArrayList<PersonaVO> personas2) {
        for (PersonaVO sujeto : personas2) {
            personas.add(new Persona(sujeto.getId(), sujeto.getNombre(), sujeto.getApellidos(), sujeto.getEdad(), sujeto.getCodigoPostal(), sujeto.getSexo(), sujeto.getCorreo()));
        }
        return personas;
    }

    public static PersonaVO convertirVo(Persona persona) {
        System.out.println(persona.getId());
        return new PersonaVO(persona.getId(), persona.getNombre(), persona.getApellidos(), persona.getEdad(), persona.getCodigoPostal(), persona.getSexo(), persona.getCorreo());
    }
}
